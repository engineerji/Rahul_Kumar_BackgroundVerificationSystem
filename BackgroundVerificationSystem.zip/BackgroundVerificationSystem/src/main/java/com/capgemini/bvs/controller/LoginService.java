package com.capgemini.bvs.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.Scanner;

import com.capgemini.bvs.dao.FileController;
import com.capgemini.bvs.model.Login;
import com.capgemini.bvs.ui.MainController;



public class LoginService {
		
	public void login(Login login) {
		System.out.println("------------------------------------------------------------------------------------------");
		Scanner scn = new Scanner(System.in);
		HashMap<Integer, Login> object1=null;
		int valid =0;
		try {
			
			ObjectInputStream in = new FileController().getLoginData();
			//System.out.println(login.getEmpId());
			object1 = ((HashMap<Integer, Login>)in.readObject());
				Login log = (Login)object1.get(login.getEmpId());
				if(log==null) {
					System.out.println("*******************Wrong EmplyeeId or Password**************************");
					new MainController().logging();
				}
				System.out.println(log.getEmpId());
				if(log.getEmpId()==login.getEmpId() && (log.getPassword().equals(login.getPassword())) ) {
					//valid =log.getRoleId();
					System.out.println("####################################################################################################");
					if(log.getEmpId()==1) {
						System.out.println("Logged in as Admin");
						System.out.println("-----------------------------------------------------------------------------------");
						new LoginImpl().AdminLogin(login);
						
					}
					else
					{
						System.out.println("Logged in as Employee");
						System.out.println("-----------------------------------------------------------------------------------");
						new LoginImpl().EmpLogin(login);
						
					}
					
				}
				else {
					System.out.println("*******************************Wrong EmplyeeId or Password*****************************");
					new MainController().logging();
				}
			
//			if(valid==0) {
//				System.out.println("Wrong EmplyeeId or Password or Role Id");
//				new BackgroundVerificationController().logging();
//			}
//			
			in.close();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
			
	}
}
