package com.capgemini.bvs.controller;

import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

import com.capgemini.bvs.dao.FileController;
import com.capgemini.bvs.model.EmployeeDocument;
import com.capgemini.bvs.model.Login;
import com.capgemini.bvs.ui.Display;
import com.capgemini.bvs.ui.MainController;



public class LoginImpl {
	Scanner scn = new Scanner(System.in);
	
	public void AdminLogin(Login login) {
		BcgService bcg = new BcgService();
		System.out.println();
		System.out.println("List of employee who have uploaded the document :");
		new Display().display();
		System.out.println("Enter the id of which you want verify the document or 0 for exit ");
		int id=0;
		try {
			id = scn.nextInt();
		}catch(Exception e) {
			System.out.println("Input should be numeric type !!!!!!!!!!!!");
			new LoginImpl().AdminLogin(login);
			
		}
		if(id==0) {
			new MainController().logging();
		}
		
		HashMap<Integer, ArrayList<EmployeeDocument>> hash=null;
		ArrayList<EmployeeDocument> list=null;
		try {
		ObjectInputStream ois =new FileController().getDocData();
		hash = (HashMap<Integer, ArrayList<EmployeeDocument>>)ois.readObject();
		list = hash.get(id);
		//System.out.println(list);
		}catch(Exception e) {
			System.out.println("no");
		}
		
		if(list==null) {
			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~No data is present~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
			new LoginImpl().AdminLogin(login);
		}
		new Display().display1(list);
		System.out.println();
		System.out.println("Enter the id of document want to verify");
		int id2 = 0;
		try {
			id2 = scn.nextInt();
		}catch(Exception e) {
			System.out.println("Input should be numeric type");
			new LoginImpl().AdminLogin(login);
			
		}
		
		EmployeeDocument dto=bcg.getDocument(list,id2);
		if(dto==null) {
			new LoginImpl().AdminLogin(login);
		}
		new Display().display2(dto);
		System.out.println("Enter 1 for reject and 2 for accept :");
		
		int choice = 0;
		try {
			choice = scn.nextInt();
		} catch (Exception e) {
			System.out.println("Please input numeric value appropriately!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
			//new BcgService().getDocument(id);
		}
		if(choice==2) {
			new BcgService().approveStatus(list,id2);
		}
		else if(choice == 1)
		{
			new BcgService().rejectStatus(list,id2);
		}
		else {
			System.out.println("Input is not appropriate!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
			//new BcgService().getDocument(id);
		}
	}
	
	
	
	
	public void EmpLogin(Login login) {
		System.out.print("What you want to do: \n1.status\n2.store\n3.Exit\n");
		int choice=0;
		try {
			choice = scn.nextInt();
		}catch(Exception e) {
			System.out.println("Input should be numeric!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
			new LoginImpl().EmpLogin(login);
		}
		if(choice == 3) {
			new MainController().logging();
		}
		
		if(choice==1) {
			new EmployeeService().viewStatus(login.getEmpId());
			new LoginImpl().EmpLogin(login);
		}
		else if(choice ==2){
			new EmployeeService().storeDocument(login);
		}
		else {
			System.out.println("Invalid choice");
			new LoginImpl().EmpLogin(login);
		}
		System.out.println("------------------------------------------------------------------------------------------------------------");
	}
}
