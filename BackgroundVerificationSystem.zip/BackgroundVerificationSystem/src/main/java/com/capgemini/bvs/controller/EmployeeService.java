package com.capgemini.bvs.controller;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;

import com.capgemini.bvs.dao.FileController;
import com.capgemini.bvs.model.EmployeeDocument;
import com.capgemini.bvs.model.Login;
import com.capgemini.bvs.model.Verification;
import com.capgemini.bvs.ui.MainController;



public class EmployeeService {
	Scanner scn = new Scanner(System.in);
	
	public void viewStatus(int empid) {
		System.out.println("------------------------------------------------------------------------------------------");
		HashMap<Integer, ArrayList<EmployeeDocument>> object1=null;
		try {
			ObjectInputStream in = new FileController().getDocData();
			
			object1 = (HashMap<Integer, ArrayList<EmployeeDocument>>)in.readObject();
			ArrayList<EmployeeDocument> list = (ArrayList<EmployeeDocument>)object1.get(empid);
			if(list!=null) {
			Iterator<EmployeeDocument> itr = list.iterator();
			while(itr.hasNext()) {
					EmployeeDocument emp =itr.next();
	//				if(emp!=null) {
						Verification vDto = emp.getVerification();
						if(empid==emp.getEmpId()) {
							System.out.println("Document data : "+emp.getDocData()+" Status is :"+vDto.getStatus());
	//					}
					}
	//				else {
	//					System.out.println("No Document is stored");
	//					System.out.println("------------------------------------------------------------------------------------------");
	//					new BackgroundVerificationController().logging();
	//				}
				}
			System.out.println("------------------------------------------------------------------------------------------");
			}
			else {
				System.out.println("No Document is stored");
				System.out.println("------------------------------------------------------------------------------------------");
				//new MainController().logging();
				return;
			}
			in.close();
			//new MainController().logging();
			return;
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	//empName, int docId, String docType, String docData
	
	
	public void storeDocument(Login logDto) {
		//System.out.println(ld.getEmpId()+""+ld.getRoleId());
		System.out.println();
		System.out.println("Enter the Employee Name :");
		String empName = scn.nextLine();
		System.out.println("Enter the Document Id :");
		int docId=0;
		
		
		try 
		{
		docId = scn.nextInt();
		}catch(Exception e) {
			System.out.println("****************Input should be numeric*********************");
			new EmployeeService().storeDocument(logDto);
		}
		
		System.out.println("Enter the Document Type\n 1. Id\n2. HSC\n3. SSC\n4. Photo");
		String docType = scn.next();
		//scn.hasNextLine();
		System.out.println("Enter the document data :");
		scn.nextLine();
		String docData = scn.nextLine();
		
		//System.out.println("Success");
		int verid = logDto.getEmpId()*10+1;
		//DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/YYYY");  
		LocalDate now = LocalDate.now();
		LocalDate tomorrow = now.plusDays(2);
	    //System.out.println(tomorrow);
		Verification verifyDto = new Verification(verid,now,tomorrow,"pending");
		System.out.println("------------------------------------------------------------------------------------------");
		System.out.println(verifyDto.getStatus());
	
		EmployeeDocument empDocDto = new EmployeeDocument(logDto.getEmpId(), empName, docId, docType, docData, verifyDto);
		
		
		HashMap<Integer, ArrayList<EmployeeDocument>> object1=null;
		ArrayList<EmployeeDocument> list = null;
		try {
			
			ObjectInputStream in = new FileController().getDocData();
			
			object1 = (HashMap<Integer, ArrayList<EmployeeDocument>>)in.readObject();
			list = object1.get(logDto.getEmpId());
			if(list==null) {
				list = new ArrayList<EmployeeDocument>();
			}
			list.add(empDocDto);
			object1.put(empDocDto.getEmpId(),list);	
			
			in.close();
			ObjectOutputStream out = new FileController().setDocData();
			out.writeObject(object1);
			
			out.close();
			System.out.println("Document stored");
			System.out.println("------------------------------------------------------------------------------------------");
			new MainController().logging();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
