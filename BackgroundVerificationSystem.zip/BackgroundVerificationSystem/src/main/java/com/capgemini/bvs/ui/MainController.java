package com.capgemini.bvs.ui;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

import com.capgemini.bvs.controller.LoginService;
import com.capgemini.bvs.controller.ResetPassword;
import com.capgemini.bvs.dao.FileUtil;
import com.capgemini.bvs.model.EmployeeDocument;
import com.capgemini.bvs.model.Login;



public class MainController {
	Scanner scn = new Scanner(System.in);
	public static void main(String[] args) {
		System.out.println("------------------------------------------------------------------------------------------");
		System.out.println("                      Background Verification System                                      ");
		System.out.println("------------------------------------------------------------------------------------------");
		//new FileUtil().util();
		new MainController().logging();
		
//		
		
		
	}
	
	public void logging() {
			int x= 0;
			
			System.out.println("1. Login ");
			System.out.println("2. Forget Password");
			System.out.println("3. Exit");
			try {
			x = scn.nextInt();
			}catch(Exception e) {
				System.out.println("Inputs are not appropriate");
				System.out.println("-------------------------------------------------------------------------------------");
				System.out.println("Login Again");
				System.out.println("-------------------------------------------------------------------------------------");
				new MainController().logging();
			}
			if(x==1) {
				try {
				System.out.println("Enter the EmpId");
				int empId = scn.nextInt();
				System.out.println("Enter the Password");
				String password = scn.next();
//				System.out.println("Enter the RoleId \n1. Admin\n2. Employee");
//				int roleId = scn.nextInt();
				Login ldto = new Login(empId, password);
				LoginService log = new LoginService();
				log.login(ldto);
				}
				catch(Exception e) {
					System.out.println("Inputs are not appropriate");
					System.out.println("-------------------------------------------------------------------------------------");
					System.out.println("Login Again");
					System.out.println("-------------------------------------------------------------------------------------");
					new MainController().logging();
				}
			}
			else if(x==2){
				new ResetPassword().resetPassword();
			}
			else if (x==3){
				System.out.println("Exited");
				System.exit(0);
			}
			else {
				System.out.println("Wrong intput");
				System.out.println("Login Again");
				System.out.println("-------------------------------------------------------------------------------------");
				new MainController().logging();
			}
	}
}
