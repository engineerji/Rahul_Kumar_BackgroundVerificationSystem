package com.capgemini.bvs.controller;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import com.capgemini.bvs.dao.FileController;
import com.capgemini.bvs.model.Login;
import com.capgemini.bvs.ui.MainController;


public class ResetPassword {
	public void resetPassword() {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter the Employee Id");
		int id = scn.nextInt();
		HashMap<Integer, Login> object1 =null;
		Login valid =null;
		try {
			
			ObjectInputStream in = new FileController().getLoginData();
			
			object1 = (HashMap<Integer, Login>)in.readObject();
			
			for (Map.Entry mapElement : object1.entrySet()) {
				Login log = (Login)mapElement.getValue();
				if(log.getEmpId()==id) {
					valid =log;
					break;
				}
			}		
			
			System.out.println("Enter the new password");
			String pass = scn.next();
			valid.setPassword(pass);
			object1.put(valid.getEmpId(), valid);
			//System.out.println("Put");
			in.close();
			ObjectOutputStream out = new FileController().setLoginData(); 
            //System.out.println(object1);
          // Method for serialization of object 
          out.writeObject(object1); 
            
          out.close(); 
          new MainController().logging();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
