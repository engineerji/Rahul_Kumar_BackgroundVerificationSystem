package com.capgemini.bvs.ui;

import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.capgemini.bvs.dao.FileController;
import com.capgemini.bvs.model.EmployeeDocument;
import com.capgemini.bvs.model.Verification;


public class Display {
	public void display1(List<EmployeeDocument> list){
		Iterator<EmployeeDocument> itr =list.iterator();
		System.out.println("####################################################################################################");
		while(itr.hasNext()) {
			EmployeeDocument emp = itr.next();
			Verification veri = emp.getVerification();
			System.out.println("Employee id - "+emp.getEmpId()+" Employee Name - "+emp.getEmpName()+" Employee Document id - "+emp.getDocId()+" Employee Document Data - "+emp.getDocData());
			System.out.println("Verification id - "+veri.getVerId()+" Verification Start date - "+veri.getStartDate()+" Verification End Date - "+veri.getEndDate()+" Verification Status - "+veri.getStatus());
			System.out.println("------------------------------------------------------------------------------------------");
		}
		System.out.println("####################################################################################################");
	}
	public void display2(EmployeeDocument emp){
		Verification veri = emp.getVerification();
		System.out.println("Employee id - "+emp.getEmpId()+" Employee Name - "+emp.getEmpName()+" Employee Document id - "+emp.getDocId()+" Employee Document Data - "+emp.getDocData());
		System.out.println("Verification id - "+veri.getVerId()+" Verification Start date - "+veri.getStartDate()+" Verification End Date - "+veri.getEndDate()+" Verification Status - "+veri.getStatus());
	}
	
	public void display() {
		try {
			
		ObjectInputStream in = new FileController().getDocData();
		HashMap<Integer, ArrayList<EmployeeDocument>> hash = (HashMap<Integer, ArrayList<EmployeeDocument>>)in.readObject();
		
		System.out.println("####################################################################################################");
		if(hash==null) {
			new MainController().logging();
		}
		for(Map.Entry ed: hash.entrySet()) {
			ArrayList<EmployeeDocument> list = hash.get(ed.getKey());
			System.out.println("Employee Id : "+list.get(0).getEmpId()+" - "+"Employee Name : "+list.get(0).getEmpName());
			System.out.println("---------------------------------------------------------------------------------------");
			}
		System.out.println("####################################################################################################");
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
