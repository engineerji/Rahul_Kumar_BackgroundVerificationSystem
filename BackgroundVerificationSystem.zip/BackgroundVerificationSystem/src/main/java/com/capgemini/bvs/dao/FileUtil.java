package com.capgemini.bvs.dao;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;

import com.capgemini.bvs.model.EmployeeDocument;
import com.capgemini.bvs.model.Login;

public class FileUtil {
	public void util(){
		File logfile = new File("C:\\Users\\rahul\\OneDrive\\Documents\\Rahul Kumar\\BackgroundVerificationSystem\\src\\main\\resources\\doc.txt");
		FileOutputStream fos=null;
		HashMap<Integer, ArrayList<EmployeeDocument>> hash = new HashMap<Integer, ArrayList<EmployeeDocument>>();
		ArrayList<EmployeeDocument> list = new ArrayList<EmployeeDocument>();
		
		
		try {
			fos = new FileOutputStream(logfile); 
	        ObjectOutputStream out = new ObjectOutputStream(fos); 
	          
	        // Method for serialization of object 
	        out.writeObject(hash); 
	          
	        out.close(); 
	        fos.close(); 
		}catch (FileNotFoundException e) {
			System.out.println("**************File is not present!!!!!!!!!!!!!!!!!!!!!!!!********************** ");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("File is Empty.!!!!!!!!!!!!!!!!!!!!! ");;
		}
		System.out.println("Done");

	
	
		File logdoc = new File("C:\\Users\\rahul\\OneDrive\\Documents\\Rahul Kumar\\BackgroundVerificationSystem\\src\\main\\resources\\login.txt");
		FileOutputStream fo=null;
		HashMap<Integer, Login> hash1 = new HashMap<Integer, Login>();
		Login log1 = new Login(1,"rahul@123");
		Login log2 = new Login(2,"kapil@123");
		Login log3 = new Login(3,"rtvik@123");
		Login log4 = new Login(4,"prince@123");
		hash1.put(log1.getEmpId(), log1);
		hash1.put(log2.getEmpId(), log2);
		hash1.put(log3.getEmpId(), log3);
		hash1.put(log4.getEmpId(), log4);
		try {
			fo = new FileOutputStream(logdoc); 
	        ObjectOutputStream ou = new ObjectOutputStream(fo); 
	          
	        // Method for serialization of object 
	        ou.writeObject(hash1); 
	          
	        ou.close(); 
	        fo.close(); 
		}catch (FileNotFoundException e) {
			System.out.println("**************File is not present!!!!!!!!!!!!!!!!!!!!!!!!********************** ");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("File is Empty.!!!!!!!!!!!!!!!!!!!!! ");;
		}
		System.out.println("Done");
	}
}
